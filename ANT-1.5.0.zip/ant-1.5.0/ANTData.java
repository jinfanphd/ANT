/**
 * Title:        ANTData.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.3
 */

// Added group information for the data output file's name
// 1/16/2002

// version 1.3.0, 8/18/2003
// add setTotalTrialNumber
package bin;
public class ANTData {
   //private ANTTrial[] trial;
   public ANTTrial[] trial;
   private int        trialCounter;
   private int        trialIndex;
   private int        trialPerBlock;
   private int        blockNumber;
   private int        totalTrialNumber;
   private String     group;
   private long       subjectID;
   private int        sessionNumber;
   private String     sex;
   private int        age;
   private String     category;
   private String[]   fourCueLocations = {  "nocue", "doublecue", "centercue", "spatialcue" };
   private String[]   threeCongruencies = { "congruent", "incongruent",  "neutral" };
   private int        RTwindowUpper;
   private int        RTwindowLower;

   public ANTData(String group, long subjectID, int sessionNumber, String sex, int age,
                                               String category) {
      //initialize variables
      //this.totalTrialNumber = totalTrialNumber;
      this.group = group;
      this.subjectID = subjectID;
      this.sessionNumber = sessionNumber;
      this.sex = sex;
      this.age = age;
      this.category = category;

      if (age <= 12)
         setChildTrial();
      else
         setAdultTrial();
   }

   public void setTotalTrialNumber(int totalTrialNumber) {
      this.totalTrialNumber = totalTrialNumber;
   }

   public void setAdultTrial() {
      totalTrialNumber = 312;
      trialCounter = totalTrialNumber;
      trialPerBlock = 96;
      blockNumber = 3;
      trialIndex = 0;
      trial = new ANTTrial[totalTrialNumber];

      this.RTwindowUpper = 1700;
      this.RTwindowLower = 100;

      ANTTrial[] trialPractice = new ANTTrial[trialPerBlock];
      for (int i = 0; i < trialPerBlock; i++) {
         trialPractice[i] = new ANTTrial(group, subjectID, sessionNumber, sex, age, category, i);
         trialPractice[i].setBlockNumber(0);
      }
      // randomize the trial order
      trialPractice = randomize(trialPractice, trialPerBlock);

      ANTTrial[][] trialTest = new ANTTrial[blockNumber][trialPerBlock];
      for (int j = 0; j < blockNumber; j ++) {
         for (int i = 0; i < trialPerBlock; i++) {
            trialTest[j][i] = new ANTTrial(group, subjectID, sessionNumber, sex, age, category, i);
         }
      }
      // set the 24 practice trials
      for (int i = 0; i < 24; i ++) {
         trial[i] = trialPractice[i];
         trial[i].setBlockNumber(0);
      }
      //set the 128 * 2 test trials
      for (int j = 0; j < blockNumber; j++) {
         trialTest[j] = randomize(trialTest[j], trialPerBlock);
         for (int i = 0; i < trialPerBlock; i++) {
            trial[j*trialPerBlock + i + 24] = trialTest[j][i];
            trial[j*trialPerBlock + i + 24].setBlockNumber(j + 1);
         }
      }
   }

   public void setChildTrial() {
      totalTrialNumber = 168;
      trialCounter = totalTrialNumber;
      trialPerBlock = 48;
      blockNumber = 3;
      trialIndex = 0;
      trial = new ANTTrial[totalTrialNumber];

      this.RTwindowUpper = 1700;
      this.RTwindowLower = 100;

      ANTTrial[] trialPractice = new ANTTrial[24];
      for (int i = 0; i < 24; i++) {
         trialPractice[i] = new ANTTrial(group, subjectID, sessionNumber, sex, age, category, i, true);
         trialPractice[i].setBlockNumber(0);
      }

      ANTTrial[][] trialTest = new ANTTrial[blockNumber][trialPerBlock];
      for (int j = 0; j < blockNumber; j ++) {
         for (int i = 0; i < trialPerBlock; i++) {
            trialTest[j][i] = new ANTTrial(group, subjectID, sessionNumber, sex, age, category, i, false);
         }
      }
      // set the 24 practice trials
      for (int i = 0; i < 24; i ++) {
         trial[i] = trialPractice[i];
         trial[i].setBlockNumber(0);
      }
      //set the 48 * 3 test trials
      for (int j = 0; j < blockNumber; j++) {
         trialTest[j] = randomize(trialTest[j], trialPerBlock);
         for (int i = 0; i < trialPerBlock; i++) {
            trial[j*trialPerBlock + i + 24] = trialTest[j][i];
            trial[j*trialPerBlock + i + 24].setBlockNumber(j + 1);
         }
      }
   }

   public boolean hasMoreTrials() {
      return trialCounter > 0;
   }

   public ANTTrial getNextTrial() {
      trialCounter--;
      return trial[trialIndex++];
   }

   public int getBlockNumber() {
      if (trialIndex > 0)
         return trial[trialIndex-1].getBlockNumber();
      else
         return 0;
   }

   public int getNextBlockNumber() {
      return trial[trialIndex].getBlockNumber();
   }

   public int getTrialNumber() {
      return trialIndex;
   }

   /**
    * Calculate alerting effect.  Treat each condition as equal weight
    */
   public String calculateAlerting() {
      String[] twoCueLocations = { "nocue", "doublecue"};
      String[] threeCongruencies = {"congruent", "incongruent",  "neutral"};

      long totalRT = 0;
      for (int i = 0; i < 1; i++) {
         for (int j = 0; j < 3; j++) {
            // long temp = calculateMeanRT(twoCueLocations[i], threeCongruencies[j]);
            long temp = calculateMedianRT(twoCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               return "NA";
            else
               totalRT += temp;
         }
      }
      for (int i = 1; i < 2; i++) {
         for (int j = 0; j < 3; j++) {
            //long temp = calculateMeanRT(twoCueLocations[i], threeCongruencies[j]);
            long temp = calculateMedianRT(twoCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               return "NA";
            else
               totalRT -= temp;
         }
      }
      return "" + Math.round(totalRT/3);
   }

   /**
    * Calculate orienting effect.  Treat each condition as equal weight
    */
   public String calculateOrienting() {
      String[] twoCueLocations = {  "centercue", "spatialcue" };
      String[] threeCongruencies = { "congruent", "incongruent", "neutral"};

      long totalRT = 0;
      for (int i = 0; i < 1; i++) {
         for (int j = 0; j < 3; j++) {
            //long temp = calculateMeanRT(twoCueLocations[i], threeCongruencies[j]);
            long temp = calculateMedianRT(twoCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               return "NA";
            else
               totalRT += temp;
         }
      }
      for (int i = 1; i < 2; i++) {
         for (int j = 0; j < 3; j++) {
            //long temp = calculateMeanRT(twoCueLocations[i], threeCongruencies[j]);
            long temp = calculateMedianRT(twoCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               return "NA";
            else
               totalRT -= temp;
         }
      }
      return "" + Math.round(totalRT/3);
   }

   /**
    * Calculate conflict effect.  Treat each condition as equal weight
    */
   public String calculateConflict() {
      long totalRT = 0;
      for (int i = 0; i < 4; i++) {
         for (int j = 1; j < 2; j++) {
            //long temp = calculateMeanRT(fourCueLocations[i], threeCongruencies[j]);
            long temp = calculateMedianRT(fourCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               return "NA";
            else
               totalRT += temp;
         }
      }
      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 1; j++) {
            //long temp = calculateMeanRT(fourCueLocations[i], threeCongruencies[j]);
            long temp = calculateMedianRT(fourCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               return "NA";
            else
               totalRT -= temp;
         }
      }
      return "" + Math.round(totalRT/4);
   }

   /**
    * calculate grand mean of RT for correct trials
    */
   public String calculateGrandMean() {
      long totalRT = 0;
      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 3; j++) {
            // long temp = calculateMeanRT(fourCueLocations[i], threeCongruencies[j]);
            long temp = calculateMedianRT(fourCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               return "NA";
            else
               totalRT += temp;
         }
      }
      return "" + Math.round(totalRT/12);
   }

   public String calculateMedianRTForEachCondition() {
      String RT = "";
      String output = "";

      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 3; j++) {
            long temp = calculateMedianRT(fourCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               RT = "NA";
            else
               RT = "" + temp;
           output = output + " " + fourCueLocations[i] + "_" + threeCongruencies[j] + "MedianRT\t" + RT + "\t";
         }
      }
      return output;
   }

   public String calculateMeanRTForEachCondition() {
      String RT = "";
      String output = "";

      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 3; j++) {
            long temp = calculateMeanRT(fourCueLocations[i], threeCongruencies[j]);
            if (temp == 0)
               RT = "NA";
            else
               RT = "" + temp;
           output = output + " " + fourCueLocations[i] + "_" + threeCongruencies[j] + "MeanRT\t" + RT + "\t";
         }
      }
      return output;
   }

   public String calculateSDForEachCondition() {
      String SD = "";
      String output = "";

      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 3; j++) {
            long mean = calculateMeanRT(fourCueLocations[i], threeCongruencies[j]);
            long temp = 0;
            if ( mean !=0 )
               temp = calculateSD(fourCueLocations[i], threeCongruencies[j], mean);

            if (temp == 0)
               SD = "NA";
            else
               SD = "" + temp;
           output = output + " " + fourCueLocations[i] + "_" + threeCongruencies[j] + "SD\t" + SD + "\t";
         }
      }
      return output;
   }

   public String calculateACCForEachCondition() {
      float ACC = 0;
      String output = "";

      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 3; j++) {
            ACC = calculateACC(fourCueLocations[i], threeCongruencies[j]);
            output = output + " " + fourCueLocations[i] + "_" + threeCongruencies[j] + "ACC\t" + ACC + "\t";
         }
      }
      return output;
   }

   /**
    * A general method to calculate mean RT for two given cue and target conditions
    * @param String cueCondition, String targetCondition
    */
   public long calculateMeanRT(String condition1, String condition2) {
      long totalRT = 0, mean = 0, sd = 0;
      int totalTrialCounter = 0;
      int correctTrialCounter = 0;

      for (int i = 0; i < totalTrialNumber; i++) {
         if (trial[i].getBlockNumber() !=0 ) {//exclude practice trial
            if ((condition1.equals(trial[i].getCueLocation())
                    && condition2.equals(trial[i].getTargetCongruency()))
                    || (condition1.equals(trial[i].getTargetCongruency())
                    && condition2.equals(trial[i].getCueLocation()))) {
                  totalTrialCounter ++;
                  // set up a window for the RT
                  if (trial[i].getCorrect() == 1 && trial[i].getRT() < RTwindowUpper
                          && trial[i].getRT() > RTwindowLower) {
                     correctTrialCounter ++;
                     totalRT = totalRT + trial[i].getRT();
                  }
            }
         }
      }
      if (correctTrialCounter != 0) {
         mean = Math.round(totalRT/correctTrialCounter);
         sd = calculateSD(condition1, condition2, mean);
      }
      if (mean !=0 && sd != 0)
         return calculateMeanRT(condition1, condition2, mean, sd);  // mean with exclusion of 3sd outlier
      else
         return 0;
   }

   /**
    * A general method to calculate mean RT for two given cue and target conditions
    * @param String cueCondition, String targetCondition, meanRT
    */
   public long calculateSD(String condition1, String condition2, long mean) {
      long totalSumOfSquaredRT = 0;
      int totalTrialCounter = 0;
      int correctTrialCounter = 0;

      for (int i = 0; i < totalTrialNumber; i++) {
         if (trial[i].getBlockNumber() !=0 ) {//exclude practice trial
            if ((condition1.equals(trial[i].getCueLocation())
                    && condition2.equals(trial[i].getTargetCongruency()))
                    || (condition1.equals(trial[i].getTargetCongruency())
                    && condition2.equals(trial[i].getCueLocation()))) {
                  totalTrialCounter ++;
                  // set up a window for the RT
                  if (trial[i].getCorrect() == 1 && trial[i].getRT() < RTwindowUpper
                        && trial[i].getRT() > RTwindowLower) {
                     correctTrialCounter ++;
                     totalSumOfSquaredRT = totalSumOfSquaredRT
                                          + (trial[i].getRT() - mean)*(trial[i].getRT() - mean);
                  }
            }
         }
      }
      if (correctTrialCounter != 0)
         return (long)Math.sqrt(totalSumOfSquaredRT/correctTrialCounter);
      else
         return 0;
   }

   /**
    * A general method to calculate mean RT for two given cue and target conditions.
    * Exclude outliers outside 2 SD
    * @param String cueCondition, String targetCondition
    */
   public long calculateMeanRT(String condition1, String condition2, long mean, long sd) {
      long totalRT = 0;
      int totalTrialCounter = 0;
      int correctTrialCounter = 0;

      for (int i = 0; i < totalTrialNumber; i++) {
         if (trial[i].getBlockNumber() !=0 ) {//exclude practice trial
            if ((condition1.equals(trial[i].getCueLocation())
                    && condition2.equals(trial[i].getTargetCongruency()))
                    || (condition1.equals(trial[i].getTargetCongruency())
                    && condition2.equals(trial[i].getCueLocation()))) {
                  totalTrialCounter ++;
                  // set up a window for the RT
                  if (trial[i].getCorrect() == 1 && trial[i].getRT() < RTwindowUpper
                        && trial[i].getRT() > RTwindowLower) {
                     if ((trial[i].getRT() < (mean + 2*sd)) && (trial[i].getRT() > (mean - 2*sd))) {
                        correctTrialCounter ++;
                        totalRT = totalRT + trial[i].getRT();
                     }
                  }
            }
         }
      }
      if (correctTrialCounter != 0)
         return Math.round(totalRT/correctTrialCounter);
      return 0;
   }

   /**
    * calculate mean accuracy for all of the correct test trials
   */
   public String calculateMeanACC() {
      long totalRT = 0;
      int totalTrialCounter = 0;
      int correctTrialCounter = 0;

      for (int i = 0; i < totalTrialNumber; i++) {
         if (trial[i].getBlockNumber() !=0 ) {//exclude practice trial
            totalTrialCounter++;
            if (trial[i].getCorrect() == 1) {
               correctTrialCounter ++;
            }
         }
      }
      if (correctTrialCounter != 0)
         return "" + Math.round(100*correctTrialCounter/totalTrialCounter);
      return "NA";
   }

   public float calculateACC(String condition1, String condition2) {
      int totalTrialCounter = 0;
      int correctTrialCounter = 0;

      for (int i = 0; i < totalTrialNumber; i++) {
         if (trial[i].getBlockNumber() !=0 ) {//exclude practice trial
            if ((condition1.equals(trial[i].getCueLocation())
                    && condition2.equals(trial[i].getTargetCongruency()))
                    || (condition1.equals(trial[i].getTargetCongruency())
                    && condition2.equals(trial[i].getCueLocation()))) {
                  totalTrialCounter ++;
                  if (trial[i].getCorrect() == 1) {
                     correctTrialCounter ++;
                  }
            }
         }
      }
      if (totalTrialCounter != 0)
         return (float)correctTrialCounter/totalTrialCounter;
      else
         return 0.0f;
   }

   /**
    * A general method to calculate median RT for two given cue and target conditions
    * @param String cueCondition, String targetCondition
    */
   public long calculateMedianRT(String condition1, String condition2) {
      int totalTrialCounter = 0;
      int correctTrialCounter = 0;

      for (int i = 0; i < totalTrialNumber; i++) {
         if (trial[i].getBlockNumber() !=0 ) {//exclude practice trial
            if ((condition1.equals(trial[i].getCueLocation())
                    && condition2.equals(trial[i].getTargetCongruency()))
                    || (condition1.equals(trial[i].getTargetCongruency())
                    && condition2.equals(trial[i].getCueLocation()))) {
                  totalTrialCounter ++;
                  // set up a window for the RT
                  if (trial[i].getCorrect() == 1 && trial[i].getRT() < RTwindowUpper
                        && trial[i].getRT() > RTwindowLower) {
                     correctTrialCounter ++;
                  }
            }
         }
      }

      if (correctTrialCounter == 0)
         return 0;

      long correctRT[] = new long[correctTrialCounter];
      correctTrialCounter = 0;
      for (int i = 0; i < totalTrialNumber; i++) {
         if (trial[i].getBlockNumber() !=0 ) {//exclude practice trial
            if ((condition1.equals(trial[i].getCueLocation())
                    && condition2.equals(trial[i].getTargetCongruency()))
                    || (condition1.equals(trial[i].getTargetCongruency())
                    && condition2.equals(trial[i].getCueLocation()))) {
                  totalTrialCounter ++;
                  // set up a window for the RT
                  if (trial[i].getCorrect() == 1 && trial[i].getRT() < RTwindowUpper
                        && trial[i].getRT() > RTwindowLower) {
                     correctRT[correctTrialCounter ++] = trial[i].getRT();
                  }
            }
         }
      }
      correctRT = sort(correctRT, correctTrialCounter);
      if ((correctTrialCounter % 2) == 0)
         return (correctRT[correctTrialCounter/2-1] + correctRT[correctTrialCounter/2])/2;
      else
         return correctRT[correctTrialCounter/2];
   }


  /**
    * Sort an array of Reaction Times using insert sort.
    * @param q an array of Objects.
    * @param n length of the array.
    */
   long[] sort(long[]q, int n)
   {
      int   first_unsorted; // position of first unsorted entry
      int   position;       // searchs sorted part of list
      long  current;        // hold the entry of temporarily removed from list

      for (first_unsorted = 1; first_unsorted < n; first_unsorted++)
        if (q[first_unsorted] < q[first_unsorted -1]) {
          position = first_unsorted;
          current = q[first_unsorted];  // pull unsorted entry out of the list
            do {
              q[position] = q[position -1];
              position --;				  // position is empty
            } while ( position > 0 && q[position -1] > current);
            q[position] = current;
        }
      return q;
   }

   public void save()
   {
      String outputFileName = "ANTdatafile_group_" + group + "_ID_" + subjectID + "_session_" + sessionNumber + ".xls";
      ANTFileOutput out = new ANTFileOutput(outputFileName);
      out.print(toString());
      out.flush();
      out.close();
   }

  /**
    * Randomizes an array of ANTTrials.
    * Rearranges them in a random order with equal probability of new
    * location for any object in the array.
    * @param array an array of Objects.
    * @param length length of the filled portion of the array.
    */
   public ANTTrial[] randomize(ANTTrial[] trial, int trialNumber)
   {
      for ( int i = 0; i < trialNumber - 1; i++ ) {
         // Select a random index, i or higher:
         int randomIndex = i + (int) (Math.random() * (trialNumber - i));

         // Swap the randomly-selected element
         // with the element at i:
         if ( i != randomIndex )  {
            ANTTrial temp = trial[i];
            trial[i] = trial[randomIndex];
            trial[randomIndex] = temp;
         }
      }
      return trial;
   }

   public int getAge() { return age; }

   public String resultSummary()
   {
      String output = "";

      output = output + "group=\t" + group
                      + "\tsubjectID=\t" + subjectID
                      + "\tsession=\t" + sessionNumber
                      + "\tsex=\t" + sex
                      + "\tage=\t" + age
                      + "\tcategory=\t" + category;
      output = output + "\tAlertEffect=\t" + calculateAlerting()
                      + "\tOrientingEffect=\t" + calculateOrienting()
                      + "\tConflictEffect=\t" + calculateConflict()
                      + "\tGrandMeanEffect=\t" + calculateGrandMean()
                      + "\tAccuracy=\t" + calculateMeanACC()
                      + "\tTrialFinished=\t" + trialIndex
                      + "\t";
      output = output + calculateMedianRTForEachCondition()
                      + calculateMeanRTForEachCondition()
                      + calculateSDForEachCondition()
                      + calculateACCForEachCondition()
                      + "\n";
      return output;
   }

   public String toString()
   {
      String output = "";
      output = "\ngroup \tsubjectID \tsession \tsex \tage \tcategory \tblock \tdate "
               + "\ttrial \tcueLocation \ttargetLocation \ttargetDirection "
               + "\ttargetCongruency \ttrialStartTime \ttragetOnTime \tfirstFixation "
               + "\tRT \tsubjectResponse \tcorrectResponse \tcorrectNess\n";
      for (int i = 0; i < totalTrialNumber; i++) {
         output = output + trial[i].getGroup()
                         + "\t" + trial[i].getSubjectID()
                         + "\t" + trial[i].getSessionNumber()
                         + "\t" + trial[i].getSex()
                         + "\t" + trial[i].getAge()
                         + "\t" + trial[i].getCategory()
                         + "\t" + trial[i].getBlockNumber()
                         + "\t" + trial[i].getDate()
                         + "\t" + (i + 1)
                         + "\t" + trial[i].getCueLocation()
                         + "\t" + trial[i].getTargetLocation()
                         + "\t" + trial[i].getTargetDirection()
                         + "\t" + trial[i].getTargetCongruency()
                         + "\t" + trial[i].getTrialStartTime()
                         + "\t" + trial[i].getTargetOnTime()
                         + "\t" + trial[i].getFirstFixationDelay()
                         + "\t" + trial[i].getRT()
                         + "\t" + trial[i].getSubjectResponse()
                         + "\t" + trial[i].getCorrectResponse()
                         + "\t" + trial[i].getCorrect()
                         + "\n";
      }

      output = output + "group=\t" + group
                      + "\tsubjectID=\t" + subjectID
                      + "\tsession=\t" + sessionNumber
                      + "\tsex=\t" + sex
                      + "\tage=\t" + age
                      + "\tcategory=\t" + category;
      output = output + "\tAlertEffect=\t" + calculateAlerting()
                      + "\tOrientingEffect=\t" + calculateOrienting()
                      + "\tConflictEffect=\t" + calculateConflict()
                      + "\tGrandMeanEffect=\t" + calculateGrandMean()
                      + "\tAccuracy=\t" + calculateMeanACC()
                      + "\tTrialFinished=\t" + trialIndex
                      + "\t";
      output = output + calculateMedianRTForEachCondition()
                      + calculateMeanRTForEachCondition()
                      + calculateSDForEachCondition()
                      + calculateACCForEachCondition()
                      + "\n";
      return output;
   }
}