// ANTDataAnalysis.java
// Programmed by Dr. Jin Fan
// 8/15/2003

// This is a program to read the data from output of Java version ANT
// in order to analyze the data further.  For example,  compare between
// left and right responses.
package bin;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.*;
import java.util.StringTokenizer;

public class ANTDataAnalysis extends JFrame {
   private JLabel display;
   private ButtonGroup fontGroup, colorGroup;
   private int style;
   private File[] inputFile;
   private File outputFile;
   private int inputFileNumber;
   private int inputResult, outputResult;
   private ObjectInputStream input;
   private ObjectOutputStream output;
   private ANTData data;
   private String displayString = "";
   private String conditionString = "all";
   private JRadioButtonMenuItem conditionItems[];
   private ButtonGroup conditionGroup;
   String condition[] = {"all", "left", "right", "up", "down"};

   public ANTDataAnalysis()
   {
      super( "ANT data analysis tool" );

      JMenuBar bar = new JMenuBar();  // create menubar
      setJMenuBar( bar );  // set the menubar for the JFrame

      // create File menu and Exit menu item
      JMenu fileMenu = new JMenu( "File" );
      fileMenu.setMnemonic( 'f' );

      JMenuItem openItem = new JMenuItem( "Open" );
      openItem.setMnemonic( 'o' );
      openItem.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               selectInputFiles();
            }
         }
      );
      fileMenu.add( openItem );

      JMenuItem saveItem = new JMenuItem( "Save" );
      saveItem.setMnemonic( 's' );
      saveItem.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               selectOutputFile();            }
            }
      );
      fileMenu.add( saveItem );

      JMenuItem exitItem = new JMenuItem( "Exit" );
      exitItem.setMnemonic( 'x' );
      exitItem.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               System.exit( 0 );
            }
         }
      );
      fileMenu.add( exitItem );
      bar.add( fileMenu );    // add File menu

      // create the Condition menu, its submenus and menu items
      JMenu conditionMenu = new JMenu( "Condition" );
      conditionMenu.setMnemonic( 'c' );
      conditionItems = new JRadioButtonMenuItem[condition.length];
      conditionGroup = new ButtonGroup();
      ItemHandler itemHandler = new ItemHandler();

      for ( int i = 0; i < condition.length; i++ ) {
         conditionItems[ i ] = new JRadioButtonMenuItem( condition[ i ] );
         conditionMenu.add( conditionItems[ i ] );
         conditionGroup.add( conditionItems[ i ] );
         conditionItems[ i ].addActionListener( itemHandler );
      }

      conditionItems[ 0 ].setSelected( true );
      conditionMenu.addSeparator();
      bar.add( conditionMenu );

      // create the Analyze menu, its submenus and menu items
      JMenu analyzeMenu = new JMenu( "Analyze" );
      JMenuItem runItem = new JMenuItem( "Run" );
      runItem.setMnemonic( 'r' );
      runItem.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               runAnalysis();
               displayString = displayString + data.resultSummary();
               display = new JLabel(displayString, SwingConstants.CENTER );
               getContentPane().add( display, BorderLayout.CENTER );
               repaint();
            }
         }
      );
      analyzeMenu.add( runItem );
      bar.add( analyzeMenu );  // add Format menu

      JMenu aboutMenu = new JMenu( "Help" );
      JMenuItem aboutItem = new JMenuItem( "About..." );
      aboutItem.setMnemonic( 'A' );
      aboutItem.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               JOptionPane.showMessageDialog( ANTDataAnalysis.this,
                  "This is for the data analysis of the ANT.\nFor any questions, please contact Dr. Jin Fan at:\nJin.Fan@cornell.edu",
                  "About", JOptionPane.PLAIN_MESSAGE );
            }
         }
      );
      aboutMenu.add( aboutItem );
      bar.add( aboutMenu );  // add Format menu

      display = new JLabel(
         displayString, SwingConstants.CENTER );
      display.setForeground(Color.black);
      display.setFont(
         new Font( "TimesRoman", Font.PLAIN, 12 ) );
      getContentPane().setBackground( Color.white );
      getContentPane().add( display, BorderLayout.CENTER );

      setSize( 500, 200 );
      show();
   }

   private void selectInputFiles()
   {
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setMultiSelectionEnabled(true);
      fileChooser.setFileSelectionMode( JFileChooser.FILES_ONLY );

      inputResult = fileChooser.showOpenDialog( this );

      // user clicked Cancel button on dialog
      if ( inputResult == JFileChooser.CANCEL_OPTION )
         inputFile = null;
      else {
         //file = fileChooser.getSelectedFile();
         inputFile = fileChooser.getSelectedFiles();
         inputFileNumber = inputFile.length;
      }
   }

   private void selectOutputFile()
   {
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setFileSelectionMode( JFileChooser.FILES_ONLY );
      fileChooser.setDialogTitle("Save");

      outputResult = fileChooser.showOpenDialog( this );

      // user clicked Cancel button on dialog
      if ( outputResult == JFileChooser.CANCEL_OPTION )
         outputFile = null;
      else {
         outputFile = fileChooser.getSelectedFile();
      }
   }

   private void runAnalysis()
   {
      if ( inputFile != null ) {
         for (int i = 0; i < inputFileNumber; i++) {
            readANTData(inputFile[i]);
            if (outputFile == null) {
               selectOutputFile();
               saveANTData(outputFile);
            }
            else
               saveANTData(outputFile);
         }
      }
   }

   public boolean readANTData(File fileName)
   {
      ANTFileInput in;
      String line;
      int totalTrialNumber = 0;
      String userGroup = "na", subjectID="0", session="0", sex="na", age = "na", category="na";
      String block="0", date="0", trial="0", cueLocation="na", targetLocation="na", targetDirection="na", targetCongruency="na";
      String trialStartTime="0", tragetOnTime="0", firstFixationDelay="0", RT="0", subjectResponse="0", correctResponse="0", correct="0";

      // check trial numbers first
      in = new ANTFileInput(fileName.toString());
      line = in.readLine();
      line = in.readLine();
      line = in.readLine();
      while ( line != null)
      {
         StringTokenizer st = new StringTokenizer(line);
         if (totalTrialNumber == 0){
            userGroup = st.nextToken();
            subjectID = st.nextToken();
            session = st.nextToken();
            sex = st.nextToken();
            age = st.nextToken();
            category = st.nextToken();
         }
         totalTrialNumber ++;
         line = in.readLine();
      }
      in.close();
      totalTrialNumber --;

      // define the ANTData
      data = new ANTData(userGroup, Long.parseLong(subjectID), Integer.parseInt(session), sex, Integer.parseInt(age), category);
      // Now, read the data
      in = new ANTFileInput(fileName.toString());
      line = in.readLine();
      line = in.readLine();
      int j = 0; //selectedTrialNumber
      for (int i = 0; i < totalTrialNumber; i++)
      {
         //JOptionPane.showMessageDialog( this, line, "Line", JOptionPane.ERROR_MESSAGE );
         line = in.readLine();
         StringTokenizer st = new StringTokenizer(line);
         userGroup = st.nextToken();
         subjectID = st.nextToken();
         session = st.nextToken();
         sex = st.nextToken();
         age = st.nextToken();
         category = st.nextToken();

         block = st.nextToken();
         data.trial[j].setBlockNumber(Integer.parseInt(block));

         date = st.nextToken();

         trial = st.nextToken();

         cueLocation = st.nextToken();
         data.trial[j].setCueLocation(cueLocation);

         targetLocation = st.nextToken();
         data.trial[j].setTargetLocation(targetLocation);

         targetDirection = st.nextToken();
         data.trial[j].setTargetDirection(targetDirection);

         targetCongruency = st.nextToken();
         data.trial[j].setTargetCongruency(targetCongruency);

         trialStartTime = st.nextToken();
         data.trial[j].setTrialStartTime(Long.parseLong(trialStartTime));

         tragetOnTime = st.nextToken();
         data.trial[j].setTargetOnTime(Long.parseLong(tragetOnTime));

         firstFixationDelay  = st.nextToken();
         data.trial[j].setFirstFixationDelay(Integer.parseInt(firstFixationDelay));

         RT = st.nextToken();
         data.trial[j].setRT(Long.parseLong(RT));

         subjectResponse = st.nextToken();
         data.trial[j].setSubjectResponse(subjectResponse);

         correctResponse = st.nextToken();
         data.trial[j].setCorrectResponse(correctResponse);

         correct = st.nextToken();
         data.trial[j].setCorrect(Integer.parseInt(correct));
         if (conditionString.equals("all"))
            j++;
         else if (conditionString.equals("left") && targetDirection.equals("left"))
            j++;
         else if (conditionString.equals("right") && targetDirection.equals("right"))
            j++;
         else if (conditionString.equals("up") && targetLocation.equals("up"))
            j++;
         else if (conditionString.equals("down") && targetLocation.equals("down"))
            j++;
      }
      in.close();
      data.setTotalTrialNumber(j);
      JOptionPane.showMessageDialog( this, conditionString, "Condition", JOptionPane.ERROR_MESSAGE );
      return true;
   }

   public void saveANTData(File fileName)
   {
      String outputFileName = fileName.toString();
      ANTFileOutput out = new ANTFileOutput(outputFileName);
      //out.print(toString());
      out.print(data.resultSummary());
      out.flush();
      out.close();
   }


   public static void main( String args[] )
   {
      ANTDataAnalysis app = new ANTDataAnalysis();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
   }

   class ItemHandler implements ActionListener {
      public void actionPerformed( ActionEvent e )
      {
         for ( int i = 0; i < conditionItems.length; i++ )
            if ( conditionItems[i].isSelected() ) {
               conditionString = condition[i];
               break;
            }
      }
   }
}

