/**
 * Title:        ANTShowResult.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class ANTShowResult extends JPanel implements ActionListener {
   private JTextField  output1, output2, output3, output4, output5;
   private JButton     saveExpButton, endExpButton;
   private long        subjectID;
   private int         sessionNumber;
   private double      result;
   private ANTData     data;
   private JFrame      frameHandler;
   private ImageIcon[] imgs;
   private ANTSound[]  sounds;
   private boolean     webVersion;
   private URL         baseURL;

   // Initialization
   public ANTShowResult(String alert, String orient, String conflict, String meanrt, String accuracy,
                        ImageIcon[] imgs,  ANTSound[]  sounds, ANTData data, boolean webVersion, URL baseURL) {
      super(new GridLayout(6,2));
      this.imgs = imgs;
      this.sounds = sounds;
      this.webVersion = webVersion;
      this.baseURL = baseURL;
      this.data = data;

      add( new JLabel( "Alerting effect (ms)", SwingConstants.RIGHT ) );
      output1 = new JTextField( 10 );
      output1.setText(alert);
      output1.setEditable(false);
      add( output1 );

      add( new JLabel( "Orienting effect (ms)", SwingConstants.RIGHT ) );
      output2 = new JTextField( 10 );
      output2.setText(orient);
      output2.setEditable(false);
      add( output2 );

      add( new JLabel( "Conflict effect (ms)", SwingConstants.RIGHT ) );
      output3 = new JTextField( 10 );
      output3.setText(conflict);
      output3.setEditable(false);
      add( output3 );

      add( new JLabel( "Mean RT for correct trials (ms)", SwingConstants.RIGHT ) );
      output4 = new JTextField( 10 );
      output4.setText(meanrt);
      output4.setEditable(false);
      add( output4 );

      add( new JLabel( "Mean accuracy (%)", SwingConstants.RIGHT ) );
      output5 = new JTextField( 10 );
      output5.setText(accuracy);
      output5.setEditable(false);
      add( output5 );

      saveExpButton = new JButton( "Save results to server");
      saveExpButton.addActionListener(this);
      add( saveExpButton );

      endExpButton = new JButton( "Do not save results to server.");
      endExpButton.addActionListener(this);
      add( endExpButton );
   }

   // Process GUI events
   public void actionPerformed( ActionEvent e ) {
      if (e.getSource() == saveExpButton) {
         frameHandler.dispose();
         sendDataToServer();
         //getSubjectInfo();
      }
      if (e.getSource() == endExpButton) {
         frameHandler.dispose();
         System.exit(0);
      }
   }

   public void sendDataToServer()
   {
      ANTClient sendData = new ANTClient(data.toString());

      JFrame frame = new JFrame("Attention Network Test: Results");
      frame.getContentPane().add(sendData, BorderLayout.CENTER);
      frame.addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );
      sendData.setFrameHandler(frame);
      frame.setSize(300, 200);
      frame.setLocation(200, 200);
      frame.show();
   }

   public void getSubjectInfo() {
      ANTSubjectInfo subjectInfo = new ANTSubjectInfo(imgs, sounds, webVersion, baseURL);

      JFrame frame = new JFrame("Attention Network Test");
      frame.getContentPane().add(subjectInfo, BorderLayout.CENTER);
      frame.addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               e.getWindow().dispose();
               System.exit( 0 );
            }
         }
      );
      subjectInfo.setFrameHandler(frame);
      frame.setSize(200, 150);
      //frame.setSize(frame.getPreferredSize());
      frame.setLocation(200, 200);
      frame.show();
   }

   public void setFrameHandler(JFrame frameHandler) {
      this.frameHandler = frameHandler;
   }
}

