This version of ANT is 1.5.0

a).fixed the keyboard error
b).I put all the files under the package called “bin” in order to make a .jar file

if you want to compile the project and run it again, do the following steps:

1. compile all the .java files in this folder by:

javac -d bin *.java

2. then the compiled files (like .class) will be saved in the bin folder. check it because sometimes it will create another bin file in it.

3. Then we need to make a new excuatable .jar file by:
jar -cvmf MANIFEST.MF ANT.jar bin

MANIFEST.MF is the file that map to the entrance of the .jar file.

The newly created .jar file will be called ANT.jar

bin is the folder contains all the previous compiled files.
