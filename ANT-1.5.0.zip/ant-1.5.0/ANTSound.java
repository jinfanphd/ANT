/**
 * Title:        ANTSound.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.net.*;
import java.applet.*;

public class ANTSound extends JPanel {
   private URL fileURL;
   private File file;
   private AudioClip clip;

   public ANTSound(URL fileURL)
   {
      this.fileURL = fileURL;
      createPlayer(fileURL);
   }

   public ANTSound(File file)
   {
      this.file = file;
      createPlayer(file);
   }

   private void createPlayer(URL fileURL)
   {
      if ( fileURL == null )
         return;

      removePreviousPlayer();

      try {
         // create a new player and add listener
         clip = Applet.newAudioClip( fileURL );
         clip.play();
      }
      catch ( Exception e ){
         JOptionPane.showMessageDialog( this,
            "Invalid file or location", "Error loading file",
            JOptionPane.ERROR_MESSAGE );
      }
   }

   private void createPlayer(File file)
   {
      if ( file == null )
         return;

      removePreviousPlayer();

      try {
         // create a new player and add listener
         clip = Applet.newAudioClip( file.toURL() );
      }
      catch ( Exception e ){
         JOptionPane.showMessageDialog( this,
            "Invalid file or location", "Error loading file",
            JOptionPane.ERROR_MESSAGE );
      }
   }

   private void removePreviousPlayer()
   {
   }

   public void play() {
      clip.play();
   }
}

