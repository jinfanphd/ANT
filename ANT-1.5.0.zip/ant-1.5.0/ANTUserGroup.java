/**
 * Title:        ANTUserGroup.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;

import java.util.StringTokenizer;
import java.util.NoSuchElementException;
import java.io.*;
import java.net.*;

public class ANTUserGroup {

   private String  userGroupToCheck;
   private String  passwdToCheck;
   private String  fileName;
   private URL     url;
   private boolean webVersion;

   public ANTUserGroup (boolean webVersion, URL url, String fileName, String userGroupToCheck, String passwdToCheck)
   {
      this.webVersion = webVersion;
      this.url = url;
      this.fileName = fileName;
      this.userGroupToCheck = userGroupToCheck;
      this.passwdToCheck = passwdToCheck;
   }

    public boolean checkUserLogin()
    {
      ANTFileInput in;
      if (webVersion)
         in = new ANTFileInput(url, fileName);
      else
         in = new ANTFileInput(fileName);

      String line = in.readLine();
      while ( line != null)
      {
         StringTokenizer st = new StringTokenizer(line);
         String userGroup = st.nextToken();
         String passwd = st.nextToken();

         if (userGroup.equals(userGroupToCheck) && passwd.equals(passwdToCheck))
             return true;
         line = in.readLine();
      }
      in.close();
      return false;
    }
}