/**
 * Title:        ANTFileOutput.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class ANTFileOutput  {

   /**  Name of text file  */
   private String filename;

   /**  Character output stream for file */
   private PrintWriter pw;

   /**
    * Creates a buffered character output
    * stream for the specified text file.
    *
    * @param filename the output text file.
    * @exception RuntimeException if an
    *            IOException is thrown when
    *            attempting to create the file.
    */
   public ANTFileOutput(String filename) {
      this.filename = filename;
      try  {
         // Using inherited protected variable out:
         pw = new PrintWriter(
                  new BufferedWriter(
                      new OutputStreamWriter(
                          new FileOutputStream(filename, true))));
      } catch ( IOException ioe )  {
         throw new RuntimeException(ioe.toString());
      }
   }  // constructor

    /**
     * Flushes the output character stream.
     * Moves characters out of all intermediate
     * memory buffers and into the file itself.
     * This method should be called after all
     * writing is completed, but before the
     * file is closed.
     */
    public void flush() { pw.flush(); }

    /**
     * Closes the file.
     * No more characters can be written
     * to the file after it is closed.
     */
    public void close() { pw.close(); }

    /**
     * Flushes the output character stream and checks whether an error has occurred.
     * Errors are cumulative; once an error is encountered, this routine will
     * return true on all successive calls.
     *
     * @return True if the print stream has encountered an error, either on the
     * underlying output stream or during a format conversion.
     */
    public boolean checkError() { return pw.checkError(); }

   /**
     * Prints a string without appending a line separator.
     *
     * @param      s   The <code>String</code> to be printed
     */
    public void print(String s) { pw.print(s); }

    /**
     * Prints an object without terminating the line.
     * Prints the <code>String</code> returned by
     * the object's <code>toString</code> method.
     *
     * @param      obj   The <code>Object</code> to be printed
     * @see        java.lang.Object#toString()
     */
    public void print(Object obj) { pw.print(obj); }

    /**
     * Terminates the current line by writing the line separator string.  The
     * line separator string is defined by the system property
     * <code>line.separator</code>, and is not necessarily a single newline
     * character (<code>'\n'</code>).
     */
    public void println() { pw.println(); }

    /**
     * Prints a String and then terminates the line.
     */
    public void println(String s) { pw.println(s); }

    /**
     * Prints an Object and then terminates the line.
     * Prints the <code>String</code> returned by
     * the object's <code>toString</code> method,
     * followed by a line separator.
     */
    public void println(Object s) { pw.println(s); }
}  // class ANTFileOutput
