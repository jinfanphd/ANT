/**
 * Title:        ANTSubjectInfo.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.3.0
 */
package bin;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;  // used for number formatting
import java.net.*;

public class ANTSubjectInfo extends JPanel implements ActionListener {
   private String         group;
   private String         passwd;
   private long           subjectID;
   private int            sessionNumber, age;
   private String         sex;
   private String         category = "normal";
   private JTextField     inputDiagonal, outputDistance, inputID, inputSession,
                          inputAge, inputSex, inputCategory, inputGroupNumber;
   private JPasswordField inputPasswd;
   private JButton        distanceButton, quitExpButton, startExpButton;
   private double         diagonal, distance;
   private double         result;
   private ANTData        data;
   private JFrame         frameHandler;
   private ImageIcon[]    imgs;
   private ANTSound[]     sounds;
   private JCheckBox      male, female;
   private String         categoryNames[] =
                             { "normal", "ADHD", "other" };
   private JComboBox      categoryBox;
   private boolean        webVersion;
   private URL            baseURL;

   public ANTSubjectInfo(ImageIcon[] imgs, ANTSound[] sounds, boolean webVersion, URL baseURL) {
      super(new GridLayout(12,2));
      this.imgs = imgs;
      this.sounds = sounds;
      this.webVersion =  webVersion;
      this.baseURL = baseURL;

      JLabel welcome = new JLabel("Welcome to Attention Network Test (ANT)",
                                  SwingConstants.CENTER);
      welcome.setFont(new Font( "Times", Font.ITALIC, 14));
      welcome.setForeground(Color.blue);
      add( welcome );
      add( new JLabel( "Version 1.3.0", SwingConstants.RIGHT ) );
      add(new JLabel( " ", SwingConstants.RIGHT ) );

      JLabel author = new JLabel( "by J. Fan, B.D. McCandliss, T. Sommer, A. Raz, & M.I. Posner",
                                   SwingConstants.RIGHT );
      author.setFont(new Font("Times", Font.PLAIN, 10));
      add(author);

      add( new JLabel( "Group Name (or guest)", SwingConstants.CENTER ) );
      inputGroupNumber = new JTextField( 10 );
      inputGroupNumber.addActionListener( this );
      add( inputGroupNumber );

      add( new JLabel( "Password (no need for guest)", SwingConstants.CENTER ) );
      inputPasswd = new JPasswordField( 10 );
      inputPasswd.addActionListener( this );
      add( inputPasswd );

      add( new JLabel( "Enter subject ID (digits only)", SwingConstants.CENTER ) );
      inputID = new JTextField( 10 );
      inputID.addActionListener( this );
      add( inputID );

      add( new JLabel( "Enter session number ", SwingConstants.CENTER ) );
      inputSession = new JTextField( 10 );
      inputSession.addActionListener( this );
      add( inputSession );

      add( new JLabel( "Enter subject age ", SwingConstants.CENTER ) );
      inputAge = new JTextField( 10 );
      inputAge.addActionListener( this );
      add( inputAge );


      add( new JLabel( "Sex ", SwingConstants.CENTER ) );
      Container sexGroup = new Container();
      sexGroup.setLayout( new FlowLayout());
      male = new JCheckBox( "Male" );
      sexGroup.add( male );
      female = new JCheckBox( "Female" );
      CheckBoxHandler handler = new CheckBoxHandler();
      male.addItemListener( handler );
      female.addItemListener( handler );
      sexGroup.add( female );
      add( sexGroup );

      add( new JLabel( "Category ", SwingConstants.CENTER ) );
      categoryBox = new JComboBox (categoryNames);
      categoryBox.setMaximumRowCount(3);
      ComboBoxHandler combohandler = new ComboBoxHandler();
      categoryBox.addItemListener( combohandler );
      add( categoryBox );

      add( new JLabel( "Diagonal of this \"Subject Info\" window is:", SwingConstants.CENTER) );
      inputDiagonal = new JTextField( 10 );
      inputDiagonal.addActionListener( this );
      add( inputDiagonal );

      distanceButton = new JButton( "Distance between eyes and screen (press this)" );
      distanceButton.addActionListener(this);
      add( distanceButton );
      outputDistance = new JTextField( 10 );
      outputDistance.setVisible(true);
      outputDistance.setEditable(false);
      add( outputDistance );

      quitExpButton = new JButton( "Quit ");
      quitExpButton.addActionListener(this);
      add( quitExpButton );

      startExpButton = new JButton( "Start practice ");
      startExpButton.addActionListener(this);
      add( startExpButton );
   }

   // Process GUI events
   public void actionPerformed( ActionEvent e ) {
      if (e.getSource() == quitExpButton) {
         frameHandler.dispose();  // dispose the subjectInfo frame
         System.exit(0);
      }
      if (e.getSource() == inputDiagonal || e.getSource() == distanceButton) {
         try {
            diagonal = Double.parseDouble( inputDiagonal.getText() );
            DecimalFormat twoDecimals = new DecimalFormat( "0.00" );
            outputDistance.setText("" + twoDecimals.format(diagonal*2.32));
            return;
         }
         catch ( NumberFormatException nfe ) {
            JOptionPane.showMessageDialog( this,
               "You must enter the diagonal length!",
               "Invalid number format for diagonal.",
               JOptionPane.ERROR_MESSAGE );
         }
      }
      try {
         subjectID = Long.parseLong( inputID.getText() );
         sessionNumber = Integer.parseInt( inputSession.getText() );
         age = Integer.parseInt( inputAge.getText() );
         if (e.getSource() == startExpButton) {
            // temp block
            group = inputGroupNumber.getText();
            // check group and password
            char[] temp = new char[20]; // less than 20 characters for the passwd
            temp = inputPasswd.getPassword(); //getText();
            passwd = "";
            for (int i = 0; i < temp.length; i ++)
               passwd = passwd + temp[i];

            if (age <= 12) { // If the age is less than 12
               JOptionPane.showMessageDialog( this,
                    "Please turn on your speaker!",
                    "Sound",
                    JOptionPane.ERROR_MESSAGE );
             }
            if (checkUser() || group.equals("guest")) { // if this is a guest
               frameHandler.dispose();  // dispose the subjectInfo frame
               showInstruction();
            }
            else {
               JOptionPane.showMessageDialog( this,
                  "Your group name or password is not correct.",
                  "Invalid group or password.",
                  JOptionPane.ERROR_MESSAGE );
            }
         }
      }
      catch ( NumberFormatException nfe ) {
         JOptionPane.showMessageDialog( this,
            "You must enter integers as subject ID, session number, or age!",
            "Invalid number format for ID, or session, or age",
            JOptionPane.ERROR_MESSAGE );
      }
   }

   public boolean checkUser() {
      ANTUserGroup checkUser;
      checkUser = new ANTUserGroup(webVersion, baseURL, "usergroup.txt", group, passwd);
      return checkUser.checkUserLogin();

   }
   public void showInstruction() {
      data = new ANTData(group, subjectID, sessionNumber, sex, age, category); //set data (trial# = 312/168)
      //System.out.println(data);
      ANTInstruction instruction = new ANTInstruction(imgs, sounds, webVersion, baseURL, data);

      JFrame app = new JFrame( "Attention Network Test" );
      app.getContentPane().add( instruction, BorderLayout.CENTER );

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               e.getWindow().dispose();
               System.exit( 0 );
            }
         }
      );
      app.setSize(640, 480); //app.getMaximumSize();
      app.setResizable(false);
      instruction.setFrameHandler(app); // send the handle to the instruction
      app.show();
   }

   public void setFrameHandler(JFrame frameHandler) {
      this.frameHandler = frameHandler;
   }

   private class CheckBoxHandler implements ItemListener {

      public void itemStateChanged( ItemEvent e )
      {
         if ( e.getSource() == male )
            if ( e.getStateChange() == ItemEvent.SELECTED ) {
               sex = "M";
               //male.setSelected(true);
               female.setSelected(false);
            }

         if ( e.getSource() == female )
            if ( e.getStateChange() == ItemEvent.SELECTED ) {
               sex = "F";
               male.setSelected(false);
               //female.setSelected(true);
            }
      }
   }

   private class ComboBoxHandler implements ItemListener {

      public void itemStateChanged( ItemEvent e )
      {
         category = categoryNames[categoryBox.getSelectedIndex()];
      }
   }
}

