/**
 * Title:        ANTServer.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ANTServer extends JFrame {
   private JTextField enter;
   private JTextArea display;
   ObjectOutputStream output;
   ObjectInputStream input;

   public ANTServer()
   {
      super( "ANTServer" );

      Container c = getContentPane();

      enter = new JTextField();
      enter.setEnabled( false );
      enter.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               sendData( e.getActionCommand() );
            }
         }
      );
      c.add( enter, BorderLayout.NORTH );

      display = new JTextArea();
      c.add( new JScrollPane( display ), BorderLayout.CENTER );

      setSize( 300, 150 );
      show();
   }

   public void runANTServer()
   {
      ServerSocket ANTServer;
      Socket connection;
      int counter = 1;
      String locationInfo = "";

      try {
         // Step 1: Create a ANTServerSocket.
         ANTServer = new ServerSocket( 5000, 100 );

         while ( true ) {
            // Step 2: Wait for a connection.
            //display.setText( locationInfo + "\nWaiting for next connection\n" );
            display.append( locationInfo + "\nWaiting for next connection\n" );
            connection = ANTServer.accept();

            locationInfo = "\nConnection " + counter + " received from: "
                           + connection.getInetAddress().getHostName() ;
            display.append( locationInfo );

            // Step 3: Get input and output streams.
            output = new ObjectOutputStream(
                         connection.getOutputStream() );
            output.flush();
            input = new ObjectInputStream(
                        connection.getInputStream() );
            display.append( "\nGot I/O streams" );

            // Step 4: Process connection.
            String message =
               "ANTServer>>> Connection successful";
            output.writeObject( message );
            output.flush();
            enter.setEnabled( true );
            String dataMessage;
            do {
               dataMessage = message;
               try {
                  message = (String) input.readObject();
                  //display.append( "\n" + message );
                  display.setCaretPosition(
                     display.getText().length() );
               }
               catch ( ClassNotFoundException cnfex ) {
                  display.append(
                     "\nUnknown object type received" );
               }
            } while ( !message.equals( "CLIENT>>> TERMINATE" ) );

            // save message to a file
            save(locationInfo + "\n" + dataMessage);

            // Step 5: Close connection.
            display.append( "\nUser terminated connection" );
            enter.setEnabled( false );
            output.close();
            input.close();
            connection.close();

            ++counter;
         }
      }
      catch ( EOFException eof ) {
         System.out.println( "Client terminated connection" );
      }
      catch ( IOException io ) {
         io.printStackTrace();
      }
   }

   private void sendData( String s )
   {
      try {
         output.writeObject( "ANTServer>>> " + s );
         output.flush();
         display.append( "\nANTServer>>>" + s );
      }
      catch ( IOException cnfex ) {
         display.append(
            "\nError writing object" );
      }
   }

   public void save(String message)
   {
      String outputFileName = "datadatabase.xls";
      ANTFileOutput out = new ANTFileOutput(outputFileName);
      out.print(message);
      out.flush();
      out.close();
   }

   public static void main( String args[] )
   {
      ANTServer app = new ANTServer();

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               System.exit( 0 );
            }
         }
      );

      app.runANTServer();
   }
}
