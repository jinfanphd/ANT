/**
 * Title:        ANT.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan, PhD
 * @author Jin Fan, PhD
 * @version 1.3.0
 */

// Version 1.2.3
// (1) Use median instead of mean for the RT.
// (2) The instruction is modified.
// RTwindow = 1000 ms for adults and 1400 ms for children, in ANTData.
// to test the program, set test = true in ANTTrial.

// Version 1.2.4
// Use Sackler DELL server, instead of Jin Fan's PC, to receive data

// Version 1.2.5
// RTwindowUpper = 1000 ms for adults and 1400 ms for children, in ANTData.
// RTwindowLower = 100 ms for adults and 100 ms for children, in ANTData.

// Added group information for the data output file's name
// 1/16/2002

// Version 1.2.6
// Fixed the problem with multiple display of feedback.  Time windows for adult
// child versions are changed back to the parameter in the papers.
// RTwindow = 1700 ms for adults and 1700 ms for children, in ANTData.
// "group number" is changed to grooup name.

// Version 1.2.7
// Added the mouseListener to let user to use mouse as a response device
// The "Taskbar ans Start Menu Properties" should be "auto hide"
// 8/8/2003

// Version 1.3.0
// Made the ANTDataAnalyze class to analyze the data offline
// 8/18/2003

// Version 1.5.0
// Fixed the bug that left and right key cannot be recognized.
// 2/10/2017

package bin;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import javax.swing.*;
import java.io.*;

public class ANT extends JApplet{
   private ImageIcon imgs[];        //the images
   private String[] imageName =
             { "arrow/fixationpoint", "arrow/centralcue",
               "arrow/lllll", "arrow/rrlrr", "arrow/ooloo",
               "arrow/rrrrr", "arrow/llrll", "arrow/ooroo",
               "arrow/correct", "arrow/incorrect",
               "arrow/noresponse", "arrow/sample",
               "fish/fixationpoint", "fish/centralcue",
               "fish/lllll", "fish/rrlrr", "fish/ooloo",
               "fish/rrrrr", "fish/llrll", "fish/ooroo",
               "fish/lllll1", "fish/rrlrr1", "fish/ooloo1",
               "fish/rrrrr1", "fish/llrll1", "fish/ooroo1",
               "fish/sample", "fish/blank"};
   private ANTSound[] sounds;
   private String[] soundName =
             { "sound/correct", "sound/wrong", "sound/alert" };

   private String dir;              //the directory relative to the codebase
                            //from which the images are loaded
   private boolean finishedLoading = false;
   private JComponent contentPane;  //the applet's content pane
   private JLabel statusLabel;
   private static Color[] labelColor = { Color.black, Color.black,
                                  Color.black, Color.black,
                                  Color.black, Color.white,
                                  Color.white, Color.white,
                                  Color.white, Color.white };
   private boolean webVersion;
   private URL baseURL;

   public void init() {
      loadImageIconFromServer();  // Load from server
   }

   public void loadImageIconFromServer() {
      this.webVersion = true;
      String at = getParameter("img");
      dir = (at != null) ? at : "stimuli";
      statusLabel = new JLabel("Loading Images...", JLabel.CENTER);
      statusLabel.setForeground(labelColor[0]);
      contentPane = new JPanel();
      contentPane.setLayout(new BorderLayout());
      contentPane.add(statusLabel, BorderLayout.CENTER);
      baseURL = getCodeBase();
      String prefix = dir + "/";
      // load images
      imgs = new ImageIcon[imageName.length];
      for (int i = 0; i < imageName.length; i++) {
         imgs[i] = new ImageIcon(getURL(baseURL, prefix + imageName[i] + ".gif"));
      }
      // load sound files
      sounds = new ANTSound[soundName.length];
      for (int i = 0; i < soundName.length; i++) {
         sounds[i] = new ANTSound(getURL(baseURL, prefix + soundName[i] + ".wav"));
      }
      finishedLoading = true;
      getSubjectInfo(imgs, sounds, webVersion, baseURL);
   }

   public void loadImageIconFromLocal() {
      this.webVersion = false;
      String prefix = "stimuli/";

      // load images
      imgs = new ImageIcon[imageName.length];
      for (int i = 0; i < imageName.length; i++) {
         imgs[i] = new ImageIcon( prefix + imageName[i] + ".gif");
      }
      // load sound files
      sounds = new ANTSound[soundName.length];
      File file;
      for (int i = 0; i < soundName.length; i++) {
         file = new File(prefix + soundName[i] + ".wav");
         sounds[i] = new ANTSound(file);
         //play sound
         //sounds[i].play();
      }
      finishedLoading = true;
      getSubjectInfo(imgs, sounds, webVersion, baseURL);
   }

   public void getSubjectInfo(ImageIcon imgs[], ANTSound[] sounds, boolean webVersion, URL baseURL) {
      ANTSubjectInfo subjectInfo = new ANTSubjectInfo(imgs, sounds, webVersion, baseURL);

      JFrame frame = new JFrame("Subject Info");
      frame.getContentPane().add(subjectInfo, BorderLayout.CENTER);
      frame.addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               e.getWindow().dispose();
               System.exit( 0 );
            }
         }
      );
      subjectInfo.setFrameHandler(frame);
      frame.setSize(640, 480);
      frame.setResizable(false);
      frame.setLocation(0, 0);
      frame.show();
   }

   protected URL getURL(URL codeBase, String filename) {
      URL url = null;

      try {
         url = new URL(codeBase, filename);
      } catch (java.net.MalformedURLException e) {
          System.out.println("Couldn't create image: badly specified URL");
          return null;
      }
      return url;
   }

   public static void main( String args[] ) {
      ANT antStart = new ANT();
      antStart.loadImageIconFromLocal();
   }
}