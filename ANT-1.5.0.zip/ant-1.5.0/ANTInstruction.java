/**
 * Title:        ANTInstruction.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class ANTInstruction extends JPanel implements ActionListener {
   private JTextArea    instructionText1, instructionText2, instructionText3;
   private JButton      sampleA, sampleB, quitExpButton, startExpButton;
   private JLabel       instructionTitle;
   private JFrame       frameHandler;
   private double       result;
   private ANTData      data;
   private ImageIcon[]  imgs;
   private ANTSound[]   sounds;
   private  boolean     webVersion;
   private URL          baseURL;
   private long         subjectID;
   private int          sessionNumber;

   public ANTInstruction(ImageIcon[] imgs, ANTSound[] sounds, boolean webVersion, URL baseURL, ANTData data) {
      this.imgs = imgs;
      this.sounds = sounds;
      this.webVersion =  webVersion;
      this.baseURL = baseURL;
      this.data = data;
      if (data.getAge() <= 12)
         displayChildInstruction();
      else
         displayAdultInstruction();
   }

   public void displayChildInstruction() {
      BorderLayout layout = new BorderLayout( 6, 1);
      setLayout( layout);
      String instructionString1 =
           "You are going to play a computer game where your job will be to feed a hungry fish using the "
         + "mouse.  \nThe way that you feed a fish when it appears on the screen is by pressing the button "
         + "on the mouse that hit the\n fish's mouth.";

      String instructionString2 =
           "Sometimes the hungry fish will be alone, the way you just saw, and sometimes the fish will be "
         + "swimming \nwith some other fish as well.  When you see more than one fish, your job is to feed "
         + "only the fish in the center. \nSo what matters is the direction the middle fish is swimming in.";

      String instructionString3 =
           "\nYou should try to feed the fish as quickly as they could, but not so fast that they would make "
         + "many mistakes.";

      instructionTitle = new JLabel( "Instruction" );
      instructionTitle.setForeground(Color.blue);
      instructionTitle.setBackground(Color.green);
      instructionTitle.setHorizontalAlignment(instructionTitle.CENTER);
      add( instructionTitle, BorderLayout.NORTH);

      // north part of instruction
      Container north = new Container();
      north.setLayout( new BorderLayout( 6, 1) );

      instructionText1 = new JTextArea( instructionString1 );
      instructionText1.setLineWrap(true);
      instructionText1.setEditable(false);
      instructionText1.setBackground(Color.cyan);
      north.add( instructionText1, BorderLayout.NORTH);

      sampleA = new JButton( imgs[16] );
      sampleA.setBackground(Color.cyan);
      sampleA.setForeground(Color.cyan);
      north.add( sampleA, BorderLayout.CENTER);

      // center part of instruction
      Container center = new Container();
      center.setLayout( new BorderLayout( 6, 1) );

      instructionText2 = new JTextArea( instructionString2 );
      instructionText2.setLineWrap(true);
      instructionText2.setEditable(false);
      instructionText2.setBackground(Color.cyan);
      center.add( instructionText2, BorderLayout.NORTH);

      sampleB = new JButton( imgs[15] );
      sampleB.setBackground(Color.cyan);
      sampleB.setForeground(Color.cyan);
      center.add( sampleB, BorderLayout.CENTER);
      // south part of instruction
      Container south = new Container();
      south.setLayout( new BorderLayout( 6, 1) );

      instructionText3 = new JTextArea( instructionString3 );
      instructionText3.setLineWrap(true);
      instructionText3.setEditable(false);
      instructionText3.setBackground(Color.cyan);
      south.add( instructionText3, BorderLayout.NORTH);

      // instruction part
      Container instruction = new Container();
      instruction.setLayout( new BorderLayout( 6, 1) );

      instruction.add(north, BorderLayout.NORTH);
      instruction.add(center, BorderLayout.CENTER);
      instruction.add(south, BorderLayout.SOUTH);

      add( instruction, BorderLayout.CENTER );

      startExpButton = new JButton( "Start practice ");
      startExpButton.setBackground(Color.lightGray);
      startExpButton.addActionListener(this);
      add( startExpButton, BorderLayout.SOUTH );
   }

   public void displayAdultInstruction() {
      BorderLayout layout = new BorderLayout( 6, 1);
      setLayout( layout);
      String instructionString1 =
           "This is an experiment investigating attention. You will be shown an arrow on the screen "
         + "pointing either to the left\n or to the right (for example -> or <- ).  Your task is to "
         + "press the left arrow key on your keyboard when the central arrow points left and the right "
         + "arrow key when the central arrow points right. On some trials, the central arrow will be\n"
         + "flanked by two arrows to the left and two arrows to the right, for example:";

      String instructionString2 =
           "Your task is to respond to the direction only of the CENTRAL arrow. Use your left index finger "
         + "for the left arrow key \nand your right index finger for the right arrow key.  "
         + "Please make your response as quickly and accurately as possible.\nYour reaction time and accuracy "
         + "will be recorded.\n"
         + "\n"
         + "There will be a cross (\"+\") in the center of the screen and the arrows will appear either "
         + "above or below the cross. \nYou should try to fixate on the cross throughout the experiment.  "
         + "Please do not move you eyes to the target.\n"
         + "\n"
         + "On some trials there will be asterisk cues indicating when or where the arrow will occur.  "
         + "If the cue is at the\n center or both above and below fixation it indicates only that the arrow "
         + "will appear shortly.  If the cue is only above or\n below fixation it indicates both that "
         + "the trial will occur shortly and where it will occur. Try to maintain fixation\n at all times.  "
         + "However, you may attend when and where indicated by the cues. \n"
         + "\n"
         + "The experiment contains four blocks. The first block is for practice and takes about two "
         + "minutes. The other\n three blocks are experimental blocks and each takes about five minutes.  "
         + "After each block there will be a\n message \"take a break\" and you may take a short rest.  "
         + "After it, you can press the space bar to begin the\n next block.  The whole experiment takes "
         + "about twenty minutes.  If you have any question, please ask the \nexperimenter.  If you "
         + "understand this instruction, you may start the practice session.";

      instructionTitle = new JLabel( "Instruction" );
      instructionTitle.setForeground(Color.blue);
      instructionTitle.setHorizontalAlignment(instructionTitle.CENTER);
      add( instructionTitle, BorderLayout.NORTH);

      Container center = new Container();
      center.setLayout( new BorderLayout( 6, 1) );


      instructionText1 = new JTextArea( instructionString1 );
      instructionText1.setLineWrap(true);
      instructionText1.setEditable(false);
      instructionText1.setBackground(Color.white);
      center.add( instructionText1, BorderLayout.NORTH);

      sampleA = new JButton( imgs[11] );
      sampleA.setBackground(Color.white);
      center.add( sampleA, BorderLayout.CENTER);

      instructionText2 = new JTextArea( instructionString2 );
      instructionText2.setLineWrap(true);
      instructionText2.setEditable(false);
      instructionText2.setBackground(Color.white);
      center.add( instructionText2, BorderLayout.SOUTH);

      add( center, BorderLayout.CENTER );

      startExpButton = new JButton( "Start practice ");
      startExpButton.addActionListener(this);
      add( startExpButton, BorderLayout.SOUTH );
   }

   // Process GUI events
   public void actionPerformed( ActionEvent e ) {
      if (e.getSource() == startExpButton) {
         frameHandler.dispose();  // dispose the subjectInfo frame
         experimentProcedure();
      }
   }

   public void experimentProcedure() {
      ANTDisplay display = new ANTDisplay(imgs, sounds, webVersion, baseURL, data);

      JFrame app = new JFrame( "Attention Network Test" );
      app.getContentPane().add( display, BorderLayout.CENTER );

      app.addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               e.getWindow().dispose();
               System.exit( 0 );
            }
         }
      );
      app.setSize(app.getMaximumSize());
      //app.setSize(1600, 1200); //app.getMaximumSize();
      display.setDisplayFrameHandler(app); // send the handle to the display
      app.show();
   }

   public void setFrameHandler(JFrame frameHandler) {
      this.frameHandler = frameHandler;
   }
}

