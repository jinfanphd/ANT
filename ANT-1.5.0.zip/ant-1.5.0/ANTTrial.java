/**
 * Title:        ANTTrial.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.3
 */

// version 1.3.0, 8/18/2003
// add several set methods
package bin;

import java.util.Calendar;

public class ANTTrial {
   // subject information
   private String     group;
   private long       subjectID;
   private int        sessionNumber;
   private String     sex;
   private int        age;
   private String     category;
   private int        blockNumber;
   private Calendar   date;
   // trial condition
   private String  cueLocation,
                   targetLocation,
                   targetDirection,
                   targetCongruency,
                   correctResponse,
                   subjectResponse;
   private int     firstFixationDelay,
                   cueDelay,
                   secondFixationDelay,
                   targetDelay,
                   lastFixationDelay;
   private long    trialStartTime,
                   targetOnTime,
                   RT;
   private int     correct;
   private boolean test = false;  //test the program

   public ANTTrial(String group, long subjectID, int sessionNumber,
                               String sex, int age, String category, int trialNumber) {
      this.group = group;
      this.subjectID = subjectID;
      this.sessionNumber = sessionNumber;
      this.sex = sex;
      this.age = age;
      this.category = category;
      date = Calendar.getInstance();

      // 96 trial per block
      //                 nocue doublecue invalidcue spatialcue
      // incongruent        8         8        8         8
      // congruent          8         8        8         8
      // neutral            8         8        8         8
      // total             24        24       24        24

      // initialize variables
      String[] fourCueLocations = { "nocue", "doublecue", "centercue", "spatialcue" };
      String[] twoTargetLocations = { "up", "down" };
      String[] twoTargetDiractions = { "left", "right" };
      String[] threeCongruencies = { "congruent", "incongruent", "neutral"};

      cueLocation = fourCueLocations[(trialNumber/12)%4];
      targetLocation = twoTargetLocations[(trialNumber/6)%2];
      targetDirection = twoTargetDiractions[(trialNumber/3)%2];
      targetCongruency = threeCongruencies[trialNumber%3];
      correctResponse = twoTargetDiractions[(trialNumber/3)%2];

      if (test) {
         firstFixationDelay = 1;
         cueDelay = 1;
         secondFixationDelay = 1;
         targetDelay = 1;
         lastFixationDelay = 1;
      }
      else {
         firstFixationDelay = 400 + (int)(Math.random()*1200);
         cueDelay = 100;
         secondFixationDelay = 400;
         targetDelay = 1700;
         lastFixationDelay = 4000 - firstFixationDelay - cueDelay
                            - secondFixationDelay - targetDelay;
      }
      RT = 0;
      correct = -1; // -1 means that there is no response
   }

   // set trial for child version
   public ANTTrial(String group, long subjectID, int sessionNumber,
                               String sex, int age, String category, int trialNumber, boolean practice) {
      this.group = group;
      this.subjectID = subjectID;
      this.sessionNumber = sessionNumber;
      this.sex = sex;
      this.age = age;
      this.category = category;
      date = Calendar.getInstance();

      if (practice) {
         String[] fourCueLocations = { "nocue", "doublecue", "centercue", "spatialcue",
                                       "spatialcue", "centercue", "doublecue", "nocue",
                                        "centercue", "spatialcue", "spatialcue", "spatialcue",
                                        "nocue", "doublecue", "nocue", "doublecue",
                                        "centercue", "spatialcue", "spatialcue", "spatialcue",
                                        "nocue", "centercue", "centercue", "doublecue" };
         String[] twoTargetLocations = { "up", "down", "up", "down",
                                         "down", "up", "up", "up",
                                         "down", "up", "down", "down",
                                         "up", "down",  "up", "down",
                                         "up", "down", "up", "down",
                                         "up",  "up", "down", "down" };
         String[] twoTargetDiractions = { "left", "right", "left", "right",
                                          "right", "left", "left", "right",
                                          "right", "left", "left", "right",
                                          "left", "left", "right", "left",
                                          "right", "right", "right", "left",
                                          "left", "right", "right", "left"};
         String[] threeCongruencies = {   "neutral", "neutral", "incongruent", "congruent",
                                        "neutral", "congruent", "congruent", "incongruent",
                                        "neutral", "incongruent",  "congruent", "incongruent",
                                        "congruent", "neutral",  "neutral", "congruent",
                                        "incongruent", "neutral", "incongruent", "congruent",
                                        "incongruent", "incongruent", "neutral", "congruent"}; // fixed order
         int[] targetDelayArray = { 3600000, 3600000, 3600000, 3600000,
                                    3600000, 3600000, 3600000, 3600000,
                                    3600000, 3600000, 3600000, 3600000,
                                    3600000, 3600000, 3600000, 3600000,
                                    3400, 3400, 3400, 3400,
                                    1700, 1700, 1700, 1700 };
         cueLocation = fourCueLocations[trialNumber%24];
         targetLocation = twoTargetLocations[trialNumber%24];
         targetDirection = twoTargetDiractions[trialNumber%24]; // Fixed order
         targetCongruency = threeCongruencies[trialNumber%24];  // Fixed order
         correctResponse = twoTargetDiractions[trialNumber%24]; // Fixed order

         firstFixationDelay = 400 + (int)(Math.random()*1200);
         cueDelay = 150;
         secondFixationDelay = 450;
         targetDelay = targetDelayArray[trialNumber%24];        // Fixed order
         lastFixationDelay = 1000;

      }
      else {
         String[] fourCueLocations = { "nocue", "doublecue", "centercue", "spatialcue" };
         String[] twoTargetLocations = { "up", "down" };
         String[] twoTargetDiractions = { "left", "right" };
         String[] threeCongruencies = { "congruent", "incongruent", "neutral"};


         cueLocation = fourCueLocations[(trialNumber/12)%4];
         targetLocation = twoTargetLocations[(trialNumber/6)%2];
         targetDirection = twoTargetDiractions[(trialNumber/3)%2];
         targetCongruency = threeCongruencies[trialNumber%3];
         correctResponse = twoTargetDiractions[(trialNumber/3)%2];

         firstFixationDelay = 400 + (int)(Math.random()*1200);
         cueDelay = 150;  // 150 ms instead of 400 ms
         secondFixationDelay = 450;  // 450 ms instead of 400 ms
         targetDelay = 1700;
         lastFixationDelay = 4000 - firstFixationDelay - cueDelay
                            - secondFixationDelay - targetDelay;
      }

      if (test) {
         firstFixationDelay = 1;
         cueDelay = 1;
         secondFixationDelay = 1;
         targetDelay = 1;
         lastFixationDelay = 1;
      }
      RT = 0;
      correct = -1; // -1 means that there is no response
   }

   public void setResponse(long reactionTime, String responseKey) {
      RT = reactionTime;
      subjectResponse = responseKey;
      if (subjectResponse.equals(correctResponse))
         correct = 1;
      else
         correct = 0;
      if (test) {
         correct = (int)Math.round(Math.random()); // for the test purpose
         //RT = 400;
         RT = 400 + (long)Math.round(Math.random()*400); // for the test purpose
      }
   }

   public void setLastFixationDelay() {
      lastFixationDelay = 4000 - firstFixationDelay - cueDelay
                          - secondFixationDelay - (targetDelay - (int)RT);
   }

   public long getTrialStartTime () { return trialStartTime; }
   public void setTrialStartTime (long trialStartTime) { this.trialStartTime = trialStartTime; }

   public long getTargetOnTime () { return targetOnTime; }
   public void setTargetOnTime (long targetOnTime) { this.targetOnTime = targetOnTime; }

   public int getBlockNumber() { return blockNumber; }
   public void setBlockNumber(int blockNumber) { this.blockNumber = blockNumber; }

   public String getGroup() { return group; }
   public void setGroup(String group) { this.group = group; }

   public long getSubjectID() { return subjectID; }
   public void setSubjectID(long subjectID) { this.subjectID = subjectID; }

   public int getSessionNumber() { return sessionNumber; }
   public void setSessionNumber(int sessionNumber) { this.sessionNumber = sessionNumber; }

   public String getSex() { return sex; }
   public void setSex(String sex) { this.sex = sex; }

   public int getAge() { return age; }
   public void setAge(int age) { this.age = age; }

   public String getCategory() { return category; }
   public void setCategory(String category) { this.category = category; }

   public String getDate() {
      String dateString = ""
         + date.get(Calendar.YEAR) + ":"
         + (date.get(Calendar.MONTH) + 1) + ":"
         + date.get(Calendar.DAY_OF_MONTH) + ":"
         + date.get(Calendar.HOUR_OF_DAY) + ":"
         + date.get(Calendar.MINUTE) + ":"
         + date.get(Calendar.SECOND);
      return dateString;
   }
   public void setDate(Calendar date) { this.date = date; };

   public String getCueLocation() { return cueLocation; }
   public void setCueLocation(String cueLocation) { this.cueLocation = cueLocation; }

   public String getTargetLocation() { return targetLocation; }
   public void setTargetLocation( String targetLocation ) { this.targetLocation = targetLocation; }

   public String getTargetDirection() { return targetDirection; }
   public void setTargetDirection(String targetDirection) { this.targetDirection = targetDirection; }

   public String getTargetCongruency() { return targetCongruency; }
   public void setTargetCongruency(String targetCongruency) { this.targetCongruency = targetCongruency; }

   public int getFirstFixationDelay() { return firstFixationDelay; }
   public void setFirstFixationDelay(int firstFixationDelay) { this.firstFixationDelay = firstFixationDelay; }

   public int getCueDelay() { return cueDelay; }
   public void setCueDelay(int cueDelay) { this.cueDelay = cueDelay; }

   public int getSecondFixationDelay() { return secondFixationDelay; }
   public void setSecondFixationDelay(int secondFixationDelay) { this.secondFixationDelay = secondFixationDelay; }

   public int getTargetDelay() { return targetDelay; }
   public void setTargetDelay(int targetDelay) { this.targetDelay = targetDelay; }

   public int getLastFixationDelay() { return lastFixationDelay; }
   public void setLastFixationDelay(int lastFixationDelay) { this.lastFixationDelay = lastFixationDelay; }

   public String getCorrectResponse() { return correctResponse; }
   public void setCorrectResponse(String correctResponse) { this.correctResponse = correctResponse; }

   public String getSubjectResponse() { return subjectResponse; }
   public void setSubjectResponse(String subjectResponse) { this.subjectResponse = subjectResponse; }

   public long getRT() { return RT; }
   public void setRT(long RT) { this.RT = RT; }

   public int getCorrect() { return correct; }
   public void setCorrect(int correct) { this.correct = correct; }

}