/**
 * Title:        ANTClient.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ANTClient extends JPanel implements ActionListener {
   private JButton cancel, enter;
   private JTextArea display;
   ObjectOutputStream output;
   ObjectInputStream input;
   String message = "";
   String dataString;
   private JFrame frameHandler;
   private BorderLayout layout;

   public ANTClient(String s)
   {
      this.dataString = s;
      layout = new BorderLayout( 5, 5);
      setLayout( layout);

      enter = new JButton("  Send data to server  ");
      enter.setEnabled( true );
      enter.addActionListener(this);
      add( enter, BorderLayout.NORTH );

      cancel = new JButton("  END  ");
      cancel.setEnabled( true );
      cancel.addActionListener(this);
      add( cancel, BorderLayout.SOUTH );

      display = new JTextArea();
      display.append("\nIf you press send button and this window\n"
                      + "does not close within 30 seconds, you\n"
                      + "may press END to cancel this transfermation.\n"
                      + "\nPress END button will end the test. " );
      add( new JScrollPane( display ), BorderLayout.CENTER );
   }

   public void runANTClient()
   {
      Socket ANTClient;
      try {
         // Step 1: Create a Socket to make connection.
         display.setText( "Attempting connection\n" );
         ANTClient = new Socket(
            //InetAddress.getByName( "127.0.0.1" ), 5000 );
            //InetAddress.getByName( "192.168.0.1" ), 5000 );  //Jin Fan
            //InetAddress.getByName( "140.251.58.37" ), 5000 );
            InetAddress.getByName( "140.251.58.136" ), 5000 ); // Sackler DELL server

         display.append( "Connected to: " +
            ANTClient.getInetAddress().getHostName() );

         // Step 2: Get the input and output streams.
         output = new ObjectOutputStream(
                      ANTClient.getOutputStream() );
         output.flush();
         input = new ObjectInputStream(
                     ANTClient.getInputStream() );
         display.append( "\nGot I/O streams\n" );

         // Step 3: Process connection.
         sendData();
         try {
            message = (String) input.readObject();
            display.append( "\n" + message );
            display.setCaretPosition( display.getText().length() );
         }
         catch ( ClassNotFoundException cnfex ) {
            display.append("\nUnknown object type received" );
         }

         // Step 4: Close connection.
         display.append( "\nData have been sent. You may END the test." );
         output.close();
         input.close();
         ANTClient.close();
      }
      catch ( EOFException eof ) {
         System.out.println( "\nServer terminated connection" );
      }
      catch ( IOException e ) {
         e.printStackTrace();
      }
   }

   public void sendData()
   {
      try {
         message = dataString;
         output.writeObject( dataString );
         output.flush();
         output.writeObject( "CLIENT>>> TERMINATE" );
         output.flush();
         //display.append( "\ndataString" );
      }
      catch ( IOException cnfex ) {
         display.append(
            "\nError writing object" );
      }
   }

   // Process GUI events
   public void actionPerformed( ActionEvent e ) {
      if (e.getSource() == enter) {
         enter.setEnabled( false );
         runANTClient();
      }
      if (e.getSource() == cancel) {
         frameHandler.dispose();  // dispose the subjectInfo frame
         System.exit( 0 );
      }
   }

   public void setFrameHandler(JFrame frameHandler) {
      this.frameHandler = frameHandler;
   }
}

