/**
 * Title:        ANTDisplay.java
 * Description:  This is the ANT project
 * Copyright:    Copyright (c) Jin Fan
 * @author Jin Fan
 * @version 1.0
 */
package bin;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;

public class ANTDisplay extends JPanel implements ActionListener, KeyListener, MouseListener{
   protected ImageIcon currentImage,
                       fixationImage,
                       firstFixationImage,
                       secondFixationImage,
                       lastFixationImage,
                       cueImage,
                       targetImage,
                       targetLllllImage,
                       targetRrlrrImage,
                       targetOolooImage,
                       targetRrrrrImage,
                       targetLlrllImage,
                       targetOorooImage,
                       correctImage,
                       incorrectImage,
                       noresponseImage,
                       targetLllll1Image,
                       targetRrlrr1Image,
                       targetOoloo1Image,
                       targetRrrrr1Image,
                       targetLlrll1Image,
                       targetOoroo1Image,
                       animationImage,
                       blankImage;

   protected int       firstFixationDelay,
                       cueDelay,
                       secondFixationDelay,
                       targetDelay,
                       feedbackDelay = 1000,
                       lastFixationDelay;

   protected int       cueLocation,
                       targetLocation;

   protected Timer     firstFixationTimer,
                       cueTimer,
                       secondFixationTimer,
                       targetTimer,
                       feedbackTimer,
                       lastFixationTimer,
                       animationTimer;
   protected long      beginTime,
                       endTime,
                       reactionTime;
   protected boolean   beginTimeOnFlag = false,
                       feedbackOnFlag = false,
                       keyReleasedFlag = false;
   protected String    responseKey;
   private ANTData     data;
   private ANTTrial    trial;
   private int         blockNumber = 0;
   private JTextArea   typingArea; // define an area to catch key response
   private JFrame      displayFrameHandler;
   private int         maxX, maxY;
   private int         animationNumber;
   private ImageIcon[] imgs;
   private ANTSound[]  sounds;
   private  boolean    webVersion;
   private URL         baseURL;

   public ANTDisplay(ImageIcon[] imgs, ANTSound[] sounds, boolean webVersion, URL baseURL, ANTData data) {
      // set the data of trial
      this.imgs = imgs;
      this.sounds = sounds;
      this.data = data;
      this.webVersion = webVersion;
      this.baseURL = baseURL;
      Dimension size = getSize();
      maxX = size.width;
      maxY = size.height;

      if (data.getAge() <= 12) {
         setBackground(Color.cyan);
         loadChildImages();
      }
      else {
         setBackground(Color.lightGray);
         loadAdultImages();
      }
      // order of the stimuli presentation
      firstFixationImage = fixationImage;
      secondFixationImage = fixationImage;
      lastFixationImage = fixationImage;
      currentImage = fixationImage;

      // set the mouse cursor to down right corner
      if (!webVersion) { // if it is not a web version, reset the mouse to right bottom
         try {
            Robot mouse = new Robot();
            mouse.mouseMove(10000, 10000);
         } catch (AWTException ae)  {
            throw new RuntimeException(ae.toString());
         }
      }
      displayInstruction();
      startDisplay();
   }

   public void loadAdultImages() {
      // load image icons
      String filePath = "stimuli/arrow";
      if (imgs.equals(null)) {  // if the ANT is run as an application NOT run from a web page
         fixationImage = new ImageIcon( filePath + "fixationpoint.gif" );
         cueImage = new ImageIcon( filePath + "centralcue.gif" );
         targetLllllImage = new ImageIcon( filePath + "lllll.gif" );
         targetRrlrrImage = new ImageIcon( filePath + "rrlrr.gif" );
         targetOolooImage = new ImageIcon( filePath + "ooloo.gif" );
         targetRrrrrImage = new ImageIcon( filePath + "rrrrr.gif" );
         targetLlrllImage = new ImageIcon( filePath + "llrll.gif" );
         targetOorooImage = new ImageIcon( filePath + "ooroo.gif" );
         correctImage = new ImageIcon( filePath + "correct.gif" );
         incorrectImage = new ImageIcon( filePath + "incorrect.gif" );
         noresponseImage = new ImageIcon( filePath + "noresponse.gif" );
      }
      else { // if the ANT is run as an applet
         fixationImage = imgs[0];
         cueImage = imgs[1];
         targetLllllImage = imgs[2];
         targetRrlrrImage = imgs[3];
         targetOolooImage = imgs[4];
         targetRrrrrImage = imgs[5];
         targetLlrllImage = imgs[6];
         targetOorooImage = imgs[7];
         correctImage = imgs[8];
         incorrectImage = imgs[9];
         noresponseImage = imgs[10];
      }

      // allow fram to process Key event
      // define a area with zero to catch key response
      typingArea = new JTextArea(1,1);
      typingArea.setBackground(Color.lightGray);
      typingArea.setEditable(false);
      typingArea.addKeyListener(this);
      typingArea.addMouseListener(this);  // add mouse listener
      add(typingArea);
      addMouseListener(this); // add mouse listener
   }

   public void loadChildImages() {
      // load image icons
      String filePath = "stimuli/fish";
      if (imgs.equals(null)) {  // if the ANT is run as an application NOT run from a web page
         fixationImage = new ImageIcon( filePath + "fixationpoint.gif" );
         cueImage = new ImageIcon( filePath + "centralcue.gif" );
         targetLllllImage = new ImageIcon( filePath + "lllll.gif" );
         targetRrlrrImage = new ImageIcon( filePath + "rrlrr.gif" );
         targetOolooImage = new ImageIcon( filePath + "ooloo.gif" );
         targetRrrrrImage = new ImageIcon( filePath + "rrrrr.gif" );
         targetLlrllImage = new ImageIcon( filePath + "llrll.gif" );
         targetOorooImage = new ImageIcon( filePath + "ooroo.gif" );

         targetLllll1Image = new ImageIcon( filePath + "lllll1.gif" );
         targetRrlrr1Image = new ImageIcon( filePath + "rrlrr1.gif" );
         targetOoloo1Image = new ImageIcon( filePath + "ooloo1.gif" );
         targetRrrrr1Image = new ImageIcon( filePath + "rrrrr1.gif" );
         targetLlrll1Image = new ImageIcon( filePath + "llrll1.gif" );
         targetOoroo1Image = new ImageIcon( filePath + "ooroo1.gif" );
         blankImage = new ImageIcon( filePath + "blank.gif" );
      }
      else { // if the ANT is run as an applet
         fixationImage = imgs[12];
         cueImage = imgs[13];
         targetLllllImage = imgs[14];
         targetRrlrrImage = imgs[15];
         targetOolooImage = imgs[16];
         targetRrrrrImage = imgs[17];
         targetLlrllImage = imgs[18];
         targetOorooImage = imgs[19];

         targetLllll1Image = imgs[20];
         targetRrlrr1Image = imgs[21];
         targetOoloo1Image = imgs[22];
         targetRrrrr1Image = imgs[23];
         targetLlrll1Image = imgs[24];
         targetOoroo1Image = imgs[25];
         blankImage = imgs[27];
      }

      // allow fram to process Key event
      // define a area with zero to catch key response
      typingArea = new JTextArea(1,1);
      typingArea.setBackground(Color.cyan);
      typingArea.setEditable(false);
      typingArea.addKeyListener(this);
      typingArea.addMouseListener(this);  // add mouse listener
      add(typingArea);
      addMouseListener(this); // add mouse listener
   }

   public void paintComponent( Graphics g ) {
      super.paintComponent( g );
      Dimension size = this.getSize();
      int maxX = size.width;
      int maxY = size.height;
      int imageX, imageY;

      if ( currentImage.getImageLoadStatus() == MediaTracker.COMPLETE ) {
         imageX = (maxX - currentImage.getIconWidth())/2;
         imageY = (maxY - currentImage.getIconHeight())/2;
         // check the cue condition
         if (currentImage.equals(cueImage)){
            if (trial.getCueLocation().equals("nocue")) {
            }
            else if (trial.getCueLocation().equals("centercue")) {
               currentImage.paintIcon( this, g, imageX, imageY );
            }
            else if (trial.getCueLocation().equals("doublecue")) {
               currentImage.paintIcon( this, g, imageX, imageY + cueLocation);
               currentImage.paintIcon( this, g, imageX, imageY - cueLocation);
            }
            else if (trial.getCueLocation().equals("invalidcue")) {
               currentImage.paintIcon( this, g, imageX, imageY + cueLocation);
            }
            else if (trial.getCueLocation().equals("spatialcue")) {
               currentImage.paintIcon( this, g, imageX, imageY + cueLocation);
            }
         }
         // check the target condition
         else if (currentImage.equals(targetImage)){
            currentImage.paintIcon( this, g, imageX, imageY + targetLocation);
         }
         else if (currentImage.equals(animationImage)){
            currentImage.paintIcon( this, g, imageX, imageY + targetLocation);
            imageX = (maxX - firstFixationImage.getIconWidth())/2;
            imageY = (maxY - firstFixationImage.getIconHeight())/2;
            firstFixationImage.paintIcon(this, g, imageX, imageY); // fixation is always on
         }

         if (currentImage.equals(correctImage)|| currentImage.equals(incorrectImage)
                   || currentImage.equals(noresponseImage))
            currentImage.paintIcon( this, g, imageX, imageY);
         else {
            imageX = (maxX - firstFixationImage.getIconWidth())/2;
            imageY = (maxY - firstFixationImage.getIconHeight())/2;
            firstFixationImage.paintIcon(this, g, imageX, imageY); // fixation is always on
        }
      }
   }

   public void actionPerformed( ActionEvent e ) {
      if (e.getSource() == firstFixationTimer){
         firstFixationTimer.stop();
         currentImage = cueImage;
         cueTimer.start();
      }
      else if (e.getSource() == cueTimer) {
         cueTimer.stop();
         currentImage = secondFixationImage;
         secondFixationTimer.start();
      }
      else if (e.getSource() == secondFixationTimer) {
         secondFixationTimer.stop();
         currentImage = targetImage;
         targetTimer.start();
         beginTime = System.currentTimeMillis(); // record the begin time
         trial.setTargetOnTime (beginTime);
         responseKey = "none";  // initialize
         reactionTime = 0;
         beginTimeOnFlag = true;
      }
      else if (e.getSource() == targetTimer) {
         targetTimer.stop();
         // if there is no response and this is a pratice trial, display deedback
         if (trial.getCorrect() == -1 && trial.getBlockNumber() == 0) {
            feedbackTimer.start();
            displayFeedback();
         }
         else if (data.getAge() <= 12) {
            feedbackTimer.start();
            displayFeedback();
         }
         else {
            currentImage = lastFixationImage;
            lastFixationTimer.start();
         }
      }
      else if (e.getSource() == feedbackTimer) {
         feedbackTimer.stop();

         if (data.getAge() <= 12) {
            animationTimer.start();
            animationNumber = 0;
            displayAnimation();
         }
         else {
            currentImage = lastFixationImage;
            lastFixationTimer.start();
         }
      }
      else if (e.getSource() == animationTimer) {
         if (animationNumber < 3) {
            animationTimer.stop();
            animationTimer.start();
            displayAnimation();
         }
         else {
            animationTimer.stop();
            currentImage = lastFixationImage;
            lastFixationTimer.start();
         }
      }
      else if (e.getSource() == lastFixationTimer) {
         lastFixationTimer.stop();
         setTrialRecord(); // set the record of this trial (RT)
         if(data.hasMoreTrials()) {      // if there are more trials
            if (data.getBlockNumber() != data.getNextBlockNumber())
               takeBreak();
            startDisplay();              // start to display the next trial
          }
         else {
            takeBreak();
            stopDisplay();
         }
      }
      repaint();
   }

   public void startDisplay() {
      setTrialCondition(); // set the first trial parameters

      if ( firstFixationTimer == null ) {  // if this is the first trial
          keyReleasedFlag = true;  // set key released true
      }
      feedbackOnFlag = false;
      firstFixationTimer = new Timer( firstFixationDelay, this );
      cueTimer = new Timer( cueDelay, this );
      secondFixationTimer = new Timer( secondFixationDelay, this );
      targetTimer = new Timer( targetDelay, this );
      feedbackTimer = new Timer (feedbackDelay, this );
      lastFixationTimer = new Timer( lastFixationDelay, this );
      animationTimer = new Timer( 333, this );
      firstFixationTimer.start();  // start the first timer of a trial
      trial.setTrialStartTime(System.currentTimeMillis()); //set trial begin time
   }

   public void stopDisplay() {
      setVisible(false);                // disable the panel of the frame
      displayFrameHandler.dispose();    // dispose the frame itself

      if (!webVersion)                  // If is it run at local, save data is true
         data.save();                   // save data to local machine
      showResult();
   }

   public void setTrialCondition() {
      int distance = 30;  // you should edit this to get different visual angle

      if(data.hasMoreTrials()) {
         trial = data.getNextTrial();
         // set duration
         firstFixationDelay = trial.getFirstFixationDelay();
         cueDelay = trial.getCueDelay();
         secondFixationDelay = trial.getSecondFixationDelay();
         targetDelay = trial.getTargetDelay();
         lastFixationDelay = trial.getLastFixationDelay();

         // set the cue location
         if (trial.getCueLocation().equals("nocue")) {
            cueLocation = 0;
         }
         else if (trial.getCueLocation().equals("centercue")) {
            cueLocation = 0;
         }
         else if (trial.getCueLocation().equals("doublecue")) {
            cueLocation = (1) * distance;
         }
         else if (trial.getCueLocation().equals("invalidcue")) {
            if (trial.getTargetLocation().equals("up"))
               cueLocation = (1) * distance;
            else if (trial.getTargetLocation().equals("down"))
               cueLocation = (-1) * distance;
         }
         else if (trial.getCueLocation().equals("spatialcue")) {
            if (trial.getTargetLocation().equals("up"))
               cueLocation = (-1) * distance;
            else if (trial.getTargetLocation().equals("down"))
               cueLocation = 1 * distance;
         }
         else
            cueLocation = 0;

         // set the target location
         if (trial.getTargetLocation().equals("up"))
            targetLocation = (-1) * distance;
         else if (trial.getTargetLocation().equals("down"))
            targetLocation = 1 * distance;
         else
            targetLocation = 0;

         // set the target direction
         if (trial.getTargetDirection().equals("left")) {
            if (trial.getTargetCongruency().equals("congruent"))
               targetImage = targetLllllImage;
            else if (trial.getTargetCongruency().equals("incongruent"))
               targetImage = targetRrlrrImage;
            else
               targetImage = targetOolooImage;
         }
         else if (trial.getTargetDirection().equals("right")) {
            if (trial.getTargetCongruency().equals("congruent"))
               targetImage = targetRrrrrImage;
            else if (trial.getTargetCongruency().equals("incongruent"))
               targetImage = targetLlrllImage;
            else
               targetImage = targetOorooImage;
         }
      }
   }

   /**
    *  record reaction time and
    */
   public void recordReactionTime(KeyEvent e) {
      endTime = System.currentTimeMillis(); // record the begin time
      if (beginTimeOnFlag && keyReleasedFlag) {
         reactionTime = endTime - beginTime;
         beginTimeOnFlag = false;
         keyReleasedFlag = false;
         if (e.getKeyCode() == 37)
            responseKey = "left";
         else if (e.getKeyCode() == 39)
            responseKey = "right";
      }
      else
         keyReleasedFlag = false;  // set key released false
      // erase the stimuli (change to fixation) on the screen
      setTrialRecord();
      displayFeedback();
   }

   /**
    *  record reaction time and
    */
   public void recordReactionTime(MouseEvent e) {
      endTime = System.currentTimeMillis(); // record the begin time
      if (beginTimeOnFlag && keyReleasedFlag) {
         reactionTime = endTime - beginTime;
         beginTimeOnFlag = false;
         keyReleasedFlag = false;
         if ((e.getModifiers() & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK)
            responseKey = "left";
         else if ((e.getModifiers() & InputEvent.BUTTON3_MASK) == InputEvent.BUTTON3_MASK)
            responseKey = "right";
      }
      else
         keyReleasedFlag = false;  // set key released false
      // erase the stimuli (change to fixation) on the screen
      setTrialRecord();
      displayFeedback();
   }

   public void setTrialRecord() {
      trial.setResponse(reactionTime, responseKey);
   }

   public void displayFeedback() {
      if (feedbackOnFlag)
         return;
      else
         feedbackOnFlag = true;
      if (data.getAge() <= 12)
         displayChildFeedback();
      else
         displayAdultFeedback();
   }

   public void displayAdultFeedback() {
      //erase the stimuli (change to fixation) on the screen
      if (trial.getBlockNumber() != 0)  //if this is not a practice trial
         currentImage = lastFixationImage;
      else {
         targetTimer.stop();
         feedbackTimer.start();
         if (trial.getCorrect() == 1)
            currentImage = correctImage;
         else if (trial.getCorrect() == 0)
            currentImage = incorrectImage;
         else
            currentImage = noresponseImage;
      }
      repaint();
   }

   public void displayChildFeedback() {
      targetTimer.stop();
      feedbackTimer.start();

      if (trial.getCorrect() == 1)
         sounds[0].play();
      else if (trial.getCorrect() == 0)
         sounds[1].play();
      else // if there is no response
         sounds[1].play();
   }

   public void displayAnimation () {
      // set the targ animation image
      if (trial.getCorrect() == 1) {
         if (animationNumber != 1) {
            if (trial.getTargetDirection().equals("left")) {
               if (trial.getTargetCongruency().equals("congruent"))
                  animationImage = targetLllll1Image;
               else if (trial.getTargetCongruency().equals("incongruent"))
                  animationImage = targetRrlrr1Image;
               else
                  animationImage = targetOoloo1Image;
            }
            else if (trial.getTargetDirection().equals("right")) {
               if (trial.getTargetCongruency().equals("congruent"))
                  animationImage = targetRrrrr1Image;
               else if (trial.getTargetCongruency().equals("incongruent"))
                  animationImage = targetLlrll1Image;
               else
                  animationImage = targetOoroo1Image;
            }
         }
         else {
            if (trial.getTargetDirection().equals("left")) {
               if (trial.getTargetCongruency().equals("congruent"))
                  animationImage = targetLllllImage;
               else if (trial.getTargetCongruency().equals("incongruent"))
                  animationImage = targetRrlrrImage;
               else
                  animationImage = targetOolooImage;
            }
            else if (trial.getTargetDirection().equals("right")) {
               if (trial.getTargetCongruency().equals("congruent"))
                  animationImage = targetRrrrrImage;
               else if (trial.getTargetCongruency().equals("incongruent"))
                  animationImage = targetLlrllImage;
               else
                  animationImage = targetOorooImage;
            }
         }
      }
      else if (trial.getCorrect() == 0 || trial.getCorrect() == -1) {
         animationImage = blankImage;
      }

      currentImage = animationImage;
      animationNumber ++;
      repaint();
   }

   public void takeBreak() {
      Object[] options = { "CONTINUE" };
      String message1 = "";
      String message2 = "";

      if (blockNumber == 0) {
         message1 = "You have finished the pratice block. Click CONTINUE to start the test.";
         message2 = "Start test";
      }
      else if (blockNumber == 1) {
         message1 = "You have finished the first block out of three test blocks. "
                   + "Take a break! Press ENTER or click CONTINUE to continue the test.";
         message2 = "Take a break";
      }
      else if (blockNumber == 2) {
         message1 = "You have finished the second block out of three test blocks. "
                   + "Take a break! Press ENTER or click CONTINUE to continue the test.";
         message2 = "Take a break";
      }
      else if (blockNumber == 3) {
         message1 = "You have finished the last block out of three test blocks. "
                   + "Click CONTINUE to see the result.";
         message2 = "Finished!";
      }

      JOptionPane.showOptionDialog(null, message1, message2,
             JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);
      blockNumber ++;
      // set the mouse cursor to down right corer
      if (!webVersion) {
         try {
            Robot mouse = new Robot();
            mouse.mouseMove(10000, 10000);
         } catch (AWTException ae)  {
            throw new RuntimeException(ae.toString());
         }
      }
   }

   public void displayInstruction() {
      Object[] options = { "CONTINUE" };
      String message1 = "Please move the mouse cursor to the right bottom corner of the monitor. "
                        + "\nIf you are ready, press ENTER to continue.";
      String message2 = "Are you ready?";

      JOptionPane.showOptionDialog(null, message1, message2,
             JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);
      // set the mouse cursor to down right corer
      if (!webVersion) {
         try {
            Robot mouse = new Robot();
            mouse.mouseMove(10000, 10000);
         } catch (AWTException ae)  {
            throw new RuntimeException(ae.toString());
         }
      }
   }

   public void showResult() {
      String alert = data.calculateAlerting();
      String orient = data.calculateOrienting();
      String conflict = data.calculateConflict();
      String meanrt = data.calculateGrandMean();
      String accuracy = data.calculateMeanACC();

      ANTShowResult showResult = new ANTShowResult(alert, orient, conflict, meanrt, accuracy,
                                                   imgs, sounds, data, webVersion, baseURL);

      JFrame frame = new JFrame("Attention Network Test: Results");
      frame.getContentPane().add(showResult, BorderLayout.CENTER);
      frame.addWindowListener( new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               e.getWindow().dispose();
               System.exit( 0 );
            }
         }
      );
      showResult.setFrameHandler(frame);
      frame.setSize(500, 400);
      frame.setLocation(200, 200);
      frame.show();
   }

   /**
    * set the handler of the frame for the display by getting the haandle
    * from ANTSubjectInfo's call of experimentProcedure()
    * @param JFrame displayFrameHandler
    */
   public void setDisplayFrameHandler(JFrame displayFrameHandler) {
     this.displayFrameHandler = displayFrameHandler;
   }

   /**
    * implements the keyPressed
    */
   public void keyPressed( KeyEvent e ) {
      System.out.println(e.getKeyCode());
      if (e.getKeyCode() == KeyEvent.VK_LEFT) {// left arrow
         recordReactionTime(e);
      }
      else if (e.getKeyCode() == KeyEvent.VK_RIGHT){ // right arrow
         recordReactionTime(e);
      }
      else if (e.getKeyCode() == KeyEvent.VK_ESCAPE){ // Escape
         stopDisplay();
      }
   }

   public void keyReleased( KeyEvent e ) {
      keyReleasedFlag = true;
   }

   public void keyTyped( KeyEvent e ) {}


   /**
    * Implementation of the MouseListener interface.
    *
    * @param e The MouseEvent
   */
   public void mousePressed(MouseEvent e){
      //System.out.println("hi");
      if ((e.getModifiers() & InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK){  // left arrow
         recordReactionTime(e);
      }
      else if ((e.getModifiers() & InputEvent.BUTTON3_MASK) == InputEvent.BUTTON3_MASK){  // right arrow
         recordReactionTime(e);
      }
   }

   public void mouseReleased(MouseEvent e){
      keyReleasedFlag = true;
   }

   public void mouseClicked(MouseEvent e){}
   public void mouseEntered(MouseEvent e){}
   public void mouseExited(MouseEvent e){}
}
